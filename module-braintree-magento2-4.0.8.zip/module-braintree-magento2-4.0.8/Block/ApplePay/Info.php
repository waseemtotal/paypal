<?php

namespace Magento\Braintree\Block\ApplePay;

/**
 * Class Info
 * @package Magento\Braintree\Model\ApplePay
 * @author Aidan Threadgold <aidan@gene.co.uk>
 */
class Info extends \Magento\Braintree\Block\Info
{
}
